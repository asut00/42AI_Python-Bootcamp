# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    Kmeans.py                                          :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: asuteau <marvin@42.fr>                     +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/06/13 15:22:11 by asuteau           #+#    #+#              #
#    Updated: 2024/06/13 15:22:15 by asuteau          ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

# height,weight,bone_density

# y aura surement un sujet de ratio a gere avec les differentes valeurs car elles ne sont pas du mm ordre de grandeur

from csvreader import CsvReader
from TinyStatistician import TinyStatistician
import numpy as np
import random

class KmeansClustering:
	def __init__(self, max_iter=20, ncentroid=4):
		self.ncentroid = ncentroid
		self.max_iter = max_iter
		self.centroids = [] 

	def fit(self, X):
		X = np.array(X)

		# on etablit les valeurs minimales et maximales pour la generation des random centroids
		min_h_value = X[:, 0].min()
		min_w_value = X[:, 1].min()
		min_bd_value = X[:, 2].min()
		max_h_value = X[:, 0].max()
		max_w_value = X[:, 1].max()
		max_bd_value = X[:, 2].max()

		# on genere les random centroids
		centroids = []
		for i in range(0, self.ncentroid):
			centroid = [random.uniform(min_h_value, max_h_value), random.uniform(min_w_value, max_w_value), random.uniform(min_bd_value, max_bd_value)]
			centroids.append(centroid)
		
		iter_num = 0

		for iter in range(self.max_iter):
			# on effectue la repartition sous forme de tableau avec chaque valeur indiquant le numero du centroid correspondant
			x = 0
			repartition = []
			for elem in X:
				centroids_l1dist = []
				for i in range(0, self.ncentroid):
					centroids_l1dist.append(abs(elem[0] - centroids[i][0]) + abs(elem[1] - centroids[i][1]) + abs(elem[2] - centroids[i][2]))
				min_l1dist = min(centroids_l1dist)
				min_l1dist_index = centroids_l1dist.index(min_l1dist)
				repartition.append(min_l1dist_index)
				x += 1

			new_centroids = np.zeros((self.ncentroid, 3))
			counter = np.zeros((self.ncentroid))

			for i in range(0, len(repartition)): # pour chaque element a l'index i dans repartition
				# j correspond a son centroid
				j = repartition[i] 
				# on incremente counter
				counter[j] = counter[j] + 1
				# on additionne le total des valeurs en vue d'obtenir la moyenne
				new_centroids[j][0] = (new_centroids[j][0] + X[i][0])
				new_centroids[j][1] = (new_centroids[j][1] + X[i][1])
				new_centroids[j][2] = (new_centroids[j][2] + X[i][2])

			# on divise les totaux par counter pour obtenir les moyennes
			for i in range(0, self.ncentroid):
				for j in range(0, len(new_centroids[i])):
					if counter[i] > 0:
						new_centroids[i][j] = new_centroids[i][j] / counter[i]

			centroids = new_centroids
			iter_num += 1

		np_centroids = np.array(centroids)
		# for elem in centroids:
		print(centroids)
		print(iter_num)


	# def predict(self, X):

if __name__=="__main__":
	csvrder = CsvReader()
	with CsvReader('/home/asuteau/Desktop/03_AI/01_PISCINE_PYTHON/03_module03/ex04/solar_system_census.csv') as file:
		data = file.getdata()
		n_data = [elem[1:] for elem in data][1:]
		nn_data = [[float(string) for string in elem] for elem in n_data]
		kmc = KmeansClustering(10000, 4)
		kmc.fit(nn_data)


		